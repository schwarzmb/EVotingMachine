import java.io.FileNotFoundException;
import java.io.IOException;

public class VoteMain {

	public static void main(String[] args) throws IOException {
		VotingInterface vote = new VotingInterface();
		RegisteredVotersDatabaseHandler rVDH = new RegisteredVotersDatabaseHandler();
		VoteDatabaseHandler vDH = new VoteDatabaseHandler();
		VoteController voteControl = new VoteController(vote, rVDH, vDH);
		boolean canVote = false;
		while(!canVote){
			canVote = voteControl.verifyVoterLogin();
		}
		int finalVote = voteControl.selectCandiates();
		voteControl.submitSelectedCandidates(finalVote);

	}

}
