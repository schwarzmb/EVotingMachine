import java.sql.*;
import java.util.ArrayList;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class VoteDatabaseHandler {
	//this voteFile contains the name of a text file used to hold votes prior to implementing a database
	private String voteFileName;
	private File voteFile;
	
	public VoteDatabaseHandler(){
		//constructor for the class
		voteFileName = "VotesTest.txt";
		voteFile = new File(voteFileName);
	}
	
	public void addVoteForCandidate(int candidateID) throws IOException{
		//this method takes a candiateID as a parameter from the controller when the vote has been submitted,
		//and adds the candidateID on a new line in the voteFile. This is counted as a vote for the candidate
		//whose ID was added.
		String tempID = String.valueOf(candidateID);
		FileWriter candidateWriter = new FileWriter(voteFileName, true);
		candidateWriter.write("\n" + tempID);
		candidateWriter.close();
	}
	
	public ArrayList<Integer> getVotes() throws FileNotFoundException{
		//this method loops through the voteFile and obtains every vote cast and adds the candidate ID for each cast vote 
		//to an ArrayList of type int. This ArrayList is returned to the controller
		//which then groups the votes by candidate
		ArrayList<Integer> returnList = new ArrayList<Integer>();
		Scanner scan = new Scanner(voteFile);
		while(scan.hasNextLine()){
			int addVote = Integer.parseInt(scan.nextLine());
			returnList.add(addVote);
		}
		scan.close();
		return returnList;
	}
	/*public static void main(String[] args) throws IOException{
		VoteDatabaseHandler test = new VoteDatabaseHandler();
		Scanner keyboard = new Scanner(System.in);
		System.out.println("Enter the candidate ID for the vote to be added(6 integers); ");
		int tempCandidateID = keyboard.nextInt();
		test.addVoteForCandidate(tempCandidateID);
		keyboard.close();
		ArrayList<Integer> testList = test.getVotes();
		System.out.println(testList);
	}*/
}
