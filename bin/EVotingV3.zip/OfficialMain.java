import java.io.FileNotFoundException;

public class OfficialMain {

	public static void main(String[] args) throws FileNotFoundException {
		ElectionOfficialInterface officialView = new ElectionOfficialInterface();
		VoteDatabaseHandler voteHandler = new VoteDatabaseHandler();
		ElectionOfficialController officialControl = new ElectionOfficialController(officialView, voteHandler);
		officialControl.actionForInput();
		

	}

}
