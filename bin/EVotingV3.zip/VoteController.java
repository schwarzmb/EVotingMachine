import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;

public class VoteController{	
	private VotingInterface voteView;
	private RegisteredVotersDatabaseHandler votersHandler;
	private VoteDatabaseHandler voteHandler;
	private CandidateInfo candidateInfo;
	
	public VoteController(VotingInterface vI, RegisteredVotersDatabaseHandler rVDB, VoteDatabaseHandler vDB){
		//this is the constructor for the VoteController class. It will initialize the attributes with 
		//the appropriate variables for them.
		this.voteView = vI;
		this.votersHandler = rVDB;
		this.voteHandler = vDB;
		//created new candidateInfo here, may need to pass it in as a parameter later, not sure.
		this.candidateInfo = new CandidateInfo();
	}
	
	public void ActionPerformed(ActionEvent e){
		//method that takes the input from the view and performs the approprate method based on the event
	}
	
	public boolean verifyVoterLogin() throws FileNotFoundException{
		//this method obtains the entered voterID from the VotingInterface and checks that the ID is 
		//registered to a registered voter. This is checked in the RegisteredVotersDatabaseHandler. If the voter
		//is found, then they will next need to have their status checked in the checkVoterStatus method.
		int ID = voteView.voterLoginForm();
		boolean idFound = votersHandler.findVoterID(ID);
		boolean rtnval = false;
		if(idFound){
			//ID was found
			System.out.println("The ID provided was found in the registered voters file");
			boolean voterStatus = this.checkVoterStatus(ID);
			if(voterStatus){
				//voter hasn't voted yet
				System.out.println("You have been successfully logged into the voting system.\n");
				rtnval = true;
			}else{
				System.out.println("You already voted in this election and may not do so again.\n");
			}
		}else{
			System.out.println("The ID provided was not found. Try again.\n");
		}
		return rtnval;
	}
	
	//helper method used in verifyVoterLogin to check Voter Status. 
	private boolean checkVoterStatus(int ID) throws FileNotFoundException{
		//this method checks that the voter hasn't already voted yet. This is checked from the registeredVotersDatabase
		//which is done through the getVoterStatus() method of the handler. If already voted then the person 
		//is not logged in, if they have not already voted then they are logged into the system and the UI updates
		//to show the candidates able to vote for.
		boolean rtnval = false;
		if(votersHandler.getVoterStatus(ID).equals("no")){
			//voter hasn't voted yet, return true
			rtnval = true;	
		}
		return rtnval;
	}
	
	//helper method that is used to show the candidate list
	/*private ArrayList<String> candidateList() throws FileNotFoundException{
		//this loop is repeated code from ElectionOfficialController. Needs to be changed so no code reuse,
		//this is just for the initial testing.
		ArrayList<String> returnList = new ArrayList<String>();
		File candidates = new File("candidatesIDsTest.txt");
		Scanner candidateScan = new Scanner(candidates);
		StringBuffer stringBuff = new StringBuffer("");
		while(candidateScan.hasNextLine()){
			String line = candidateScan.nextLine();
			String[] split = line.split(" ");
			//trying something new, making it so it breaks up into parts by what role candidate is running for
			if(split[0].equals("||")){
				String[] tempArray = Arrays.copyOfRange(split, 1, split.length);
				//used helper method arrayToString to make to string in proper format.
				stringBuff.append(arrayToString(tempArray) + "\n");
			}else if(split[0].equals("break")){
				//this is the end of the candidates for that position. 
				//Add to the stringbuffer and then reset stringbuff to ("")
				String pos = stringBuff.toString();
				returnList.add(pos);
				stringBuff.setLength(0);
			}else if(split[0].equals("end")){
				//this is the end of the list. break from loop
				break;		
			}else{
				//this is where the candidates and their info gets added to the stringBuffer.
				int candidateID = Integer.parseInt(split[0]);
				//the split.length -1 is the candidates name without the Party. making party separate
				int delim = split.length -1;
				String candidateName = arrayToString(Arrays.copyOfRange(split, 1, delim));
				String party = arrayToString(Arrays.copyOfRange(split, delim, split.length));
				String currentCandidate = (candidateName + " (" + party + "): " +  candidateID + "\n");
				stringBuff.append(currentCandidate);		
			}
		}
		candidateScan.close();
		return returnList;
	}*/
	
	//helper method to convert String[] to string with correct formatting
	/*private String arrayToString(String[] list){
		StringBuilder sb = new StringBuilder();
		boolean first = true;
		for(String item : list){
			if(!first){
				sb.append(" ");
			}
			sb.append(item);
			first = false;
		}
		return sb.toString();
	}*/
	
	//this method is to get the positions from the file
	/*public ArrayList<String> positions() throws FileNotFoundException{
		ArrayList<String> position = new ArrayList<String>();
		File candidates = new File("candidatesIDsTest.txt");
		Scanner candidateScan = new Scanner(candidates);
		while(candidateScan.hasNextLine()){
			String[] splitLine = candidateScan.nextLine().split(" ");
			if(splitLine[0].equals("||")){
				String temp = Arrays.copyOfRange(splitLine, 1, splitLine.length).toString();
				position.add(temp);
			}else if(splitLine[0].equals("end")){
				break;
			}
		}
		candidateScan.close();
		return position;
	}*/
	
	
	//this method is what actually selects the candidates from the interface.
	public int[] selectCandiates() throws FileNotFoundException{
		ArrayList<String> candidates = candidateInfo.candidateList();
		//placeholder for currentVote
		int[] currentVotes = new int[candidates.size()];
		boolean confirm = false;
		while(!confirm){
			for(int i = 0; i < candidates.size(); i++){
				String currPosition = candidates.get(i);
				System.out.println(currPosition);
				int vote = voteView.voteForCandidate(currPosition);
				currentVotes[i] = vote;
			}
			confirm = voteView.confirmVote(this.showCurrentVotes(currentVotes));
		}
		return currentVotes;
	}
	
	//THIS METHOD IS EXACTLY FROM OFFICIAL CONTROLLER!!! NOT GOOD!! WILL CHANGE WHEN USING DATABASE SINCE WON'T NEED
	/*private boolean isInteger(String input){
		try{
			Integer.parseInt(input);
			return true;
		}catch(Exception e){
			return false;
		}
	}*/
	
	//helper method for reviewing votes. creates a string showing who is currently voted for.
	//I copied code from the ElectionOfficialController so that'll need to be dealt with later when using database.
	private String showCurrentVotes(int[] votes) throws FileNotFoundException{
		//ArrayList<String> nameAndID = candidateInfo.candidateNameAndID();
		StringBuffer stringBuff = new StringBuffer("");
		for(int i = 0; i < candidateInfo.numberOfCandidates(); i++){
			String candidateName = candidateInfo.candidateName(i);
			int candidateID = candidateInfo.candidateID(i);
			for(int j = 0; j < votes.length; j++){
				if(votes[j] == candidateID){
					stringBuff.append(candidateName + "\n");
					break;
				}
			}
		}
		return stringBuff.toString();
	}
	
	public void submitSelectedCandidates(int[] votes) throws IOException{
		//this method will send the selected candidates to the voteDatabaseHandler to add to their vote amount.
		//this method is performed when the select votes button is pressed, and after the confirm vote message is shown.
		for(int i = 0; i < votes.length; i++){
			int vote = votes[i];
			this.voteHandler.addVoteForCandidate(vote);
		}
	}
	
	
	
	/*public static void main(String[] args) throws IOException{
		VotingInterface vote = new VotingInterface();
		RegisteredVotersDatabaseHandler rVDH = new RegisteredVotersDatabaseHandler();
		VoteDatabaseHandler vDH = new VoteDatabaseHandler();
		VoteController test = new VoteController(vote, rVDH, vDH);
		boolean canVote = false;
		ArrayList<String> temp = test.positions();
		Object[] tempArr = temp.toArray();
		String[] positions = Arrays.copyOf(tempArr, tempArr.length, String[].class);
		for(int i=0; i < positions.length; i++){
            System.out.println(positions[i]);
            }
			//while(!canVote){
			//	canVote = test.verifyVoterLogin();
			//}
			//int finalVote = test.selectCandiates();
			//test.submitSelectedCandidates(finalVote);
	}*/
}
